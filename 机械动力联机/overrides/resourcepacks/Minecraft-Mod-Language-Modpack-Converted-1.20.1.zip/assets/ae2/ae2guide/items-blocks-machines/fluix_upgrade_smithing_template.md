---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯升级锻造模板
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# 福鲁伊克斯升级锻造模板

和原版的锻造模板不同，这个锻造模板可以直接制造。

为[福鲁伊克斯工具](fluix_tools.md)所必需。

## 配方

<RecipeFor id="fluix_upgrade_smithing_template" />