---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英水晶
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# 赛特斯石英水晶

<ItemImage id="certus_quartz_crystal" scale="4" />

*“赛特斯石英水晶具有能在其晶态基质中存储大量能量的独特性质”*

AE2方块、[设备](../ae2-mechanics/devices.md)、物品的基础合成材料之一。由培养[赛特斯石英母岩](../ae2-mechanics/certus-growth.md)获得。

## 部分替代配方

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
